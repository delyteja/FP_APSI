<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Action</th>
      <th scope="col">id</th>
      <th scope="col">nama</th>
      <th scope="col">alamat</th>
      <th scope="col">no hp</th>
      <th scope="col">email</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>
        <a href="/edit">edit</a>
        <a onclick="deletebox()" href="#">delete</a>
      </td>
      <td>041</td>
      <td>Farza Nurifan</td>
      <td>Surabaya</td>
      <td>082330239557</td>
      <td>farza@nurifan.com</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>
        <a href="#">edit</a>
        <a href="#">delete</a>
      </td>
      <td>041</td>
      <td>Farza Nurifan</td>
      <td>Surabaya</td>
      <td>082330239557</td>
      <td>farza@nurifan.com</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>
        <a href="#">edit</a>
        <a href="#">delete</a>
      </td>
      <td>041</td>
      <td>Farza Nurifan</td>
      <td>Surabaya</td>
      <td>082330239557</td>
      <td>farza@nurifan.com</td>
    </tr>
  </tbody>
</table>
<a href="/add" class="btn btn-primary">add data</a>
